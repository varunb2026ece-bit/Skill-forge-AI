create extension if not exists pgcrypto;

create table if not exists public.learner_profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  education text,
  target_career text,
  skills jsonb not null default '[]'::jsonb,
  certifications jsonb not null default '[]'::jsonb,
  projects jsonb not null default '[]'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.roadmaps (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  target_career text not null,
  input_snapshot jsonb not null,
  agent_result jsonb not null,
  status text not null default 'active' check (status in ('active','completed','archived')),
  created_at timestamptz not null default now()
);

create table if not exists public.assessments (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  roadmap_id uuid references public.roadmaps(id) on delete set null,
  topic text not null,
  score numeric(5,2) check (score >= 0 and score <= 100),
  max_score numeric(5,2) not null default 100,
  answers jsonb not null default '[]'::jsonb,
  feedback jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists public.learning_progress (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  roadmap_id uuid not null references public.roadmaps(id) on delete cascade,
  week_number int not null check (week_number > 0),
  task_key text not null,
  completed boolean not null default false,
  completed_at timestamptz,
  updated_at timestamptz not null default now(),
  unique (user_id, roadmap_id, task_key)
);

create index if not exists roadmaps_user_created_idx on public.roadmaps(user_id, created_at desc);
create index if not exists assessments_user_created_idx on public.assessments(user_id, created_at desc);
create index if not exists progress_user_roadmap_idx on public.learning_progress(user_id, roadmap_id);

alter table public.learner_profiles enable row level security;
alter table public.roadmaps enable row level security;
alter table public.assessments enable row level security;
alter table public.learning_progress enable row level security;

create policy "Learners manage own profile" on public.learner_profiles
for all to authenticated
using ((select auth.uid()) = id)
with check ((select auth.uid()) = id);

create policy "Learners manage own roadmaps" on public.roadmaps
for all to authenticated
using ((select auth.uid()) = user_id)
with check ((select auth.uid()) = user_id);

create policy "Learners manage own assessments" on public.assessments
for all to authenticated
using ((select auth.uid()) = user_id)
with check ((select auth.uid()) = user_id);

create policy "Learners manage own progress" on public.learning_progress
for all to authenticated
using ((select auth.uid()) = user_id)
with check ((select auth.uid()) = user_id);
