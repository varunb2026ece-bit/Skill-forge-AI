-- Private answer keys are isolated from learner-readable assessment rows.
-- Only server-side service-role operations can access this table; do not add authenticated policies.
create table if not exists public.assessment_answer_keys (
  assessment_id uuid primary key references public.assessments(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  answer_key jsonb not null,
  created_at timestamptz not null default now()
);

alter table public.assessment_answer_keys enable row level security;

-- No policies are intentionally defined: anon/authenticated clients cannot read answer keys.
create index if not exists assessment_answer_keys_user_idx
  on public.assessment_answer_keys(user_id);

-- Replace the broad CRUD policy created in migration 0001. Learners may read their
-- own results, but assessment creation/scoring is performed only by authenticated
-- server routes using the server-only service-role key.
drop policy if exists "Learners manage own assessments" on public.assessments;
drop policy if exists "Learners read own assessments" on public.assessments;
create policy "Learners read own assessments" on public.assessments
for select to authenticated
using ((select auth.uid()) = user_id);
