-- Keep learner profile timestamps consistent on every update.
create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists learner_profiles_set_updated_at on public.learner_profiles;
create trigger learner_profiles_set_updated_at
before update on public.learner_profiles
for each row execute function public.set_updated_at();

-- Explicitly constrain roadmap ownership to authenticated users. Existing RLS policies
-- from 0001 remain the enforcement boundary for all learner-owned tables.
