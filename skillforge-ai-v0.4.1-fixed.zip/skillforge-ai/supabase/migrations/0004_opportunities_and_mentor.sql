create table if not exists public.mentor_messages (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null check (role in ('user','assistant')),
  content text not null check (char_length(content) between 1 and 4000),
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index if not exists mentor_messages_user_created_idx on public.mentor_messages(user_id, created_at);
alter table public.mentor_messages enable row level security;
create policy "Learners read own mentor messages" on public.mentor_messages for select to authenticated using ((select auth.uid()) = user_id);
create policy "Learners insert own mentor messages" on public.mentor_messages for insert to authenticated with check ((select auth.uid()) = user_id);
-- No client-side updates/deletes: conversation writes are performed by authenticated server routes.
