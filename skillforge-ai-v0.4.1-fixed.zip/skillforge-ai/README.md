# SkillForge AI

Multi-agent career and personalized learning platform built with Next.js App Router, TypeScript, Supabase Auth/Postgres/RLS, and Gemini.

## Requirements
- Node.js 22+ and npm
- A Supabase project
- A Gemini API key from Google AI Studio

## 1. Install and configure
```bash
npm install
cp .env.example .env.local
```
Fill in `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY`, `GEMINI_API_KEY`, and the server-only `SUPABASE_SERVICE_ROLE_KEY`. Keep the Gemini key server-only; never use a `NEXT_PUBLIC_` prefix for it.

## 2. Configure Supabase
Run these SQL files in order in Supabase SQL Editor:
1. `supabase/migrations/0001_skillforge.sql`
2. `supabase/migrations/0002_auth_and_profile_integrity.sql`
3. `supabase/migrations/0003_assessments_adaptive_learning.sql`

In Supabase Authentication → URL Configuration:
- Set local Site URL to `http://localhost:3000`.
- Add `http://localhost:3000/auth/callback` to allowed redirect URLs.
- For production, add your production callback URL and configure reliable SMTP/email delivery.

## 3. Run
```bash
npm run dev
```
Open `http://localhost:3000`. Run `npm run typecheck` and `npm run build` before deployment.

## Implemented
- Dark SkillForge dashboard UI.
- Email/password sign-up and sign-in at `/login`.
- Email confirmation callback at `/auth/callback`.
- Server-protected `/dashboard`; unauthenticated visitors are redirected to `/login`.
- Dashboard loads the signed-in learner's saved profile and latest roadmap.
- `/api/agents/roadmap` authenticates the user, runs Profile → Skill Gap → Roadmap → Mentor agents, upserts the learner profile, and saves the generated roadmap.
- Supabase RLS policies restrict learner data to its owner.
- AI assessment generation creates five career-aligned multiple-choice questions.
- Correct answers are stored in a separate RLS-protected table with no client policies and accessed only through the server-side service-role key.
- Assessment submission is scored server-side; per-skill performance and explanations are saved.
- Adaptive Learning Agent appends evidence-based updates to the linked roadmap, preserving the existing roadmap content.
- Browser/server Supabase clients and Next.js proxy session refresh.

## Known limitations
- Dashboard score, streak, opportunity count, and growth chart are illustrative demo metrics, not measured learner outcomes.
- AI skill-gap labels and learning plans are advisory, not validated employment assessments.
- Resource suggestions are search queries, not verified URLs.
- Sign-up confirmation, database persistence, Gemini generation, and assessment workflows require your own Supabase/Gemini credentials and project configuration; they have not been live-tested in this environment. Apply migration 0003 and set SUPABASE_SERVICE_ROLE_KEY for private answer-key operations.
- Add rate limiting, abuse protection, structured agent logs, and production monitoring before public deployment.

## Assessment and adaptive-learning milestone (v0.3)
- Generate five career-specific MCQs from the learner's saved profile and active roadmap.
- Keep correct answers in `assessment_answer_keys`, a separate RLS-enabled table with no authenticated policies.
- Use `SUPABASE_SERVICE_ROLE_KEY` only in server routes to create/read answer keys and save scores.
- Submit answers to a server endpoint; score and explanations are computed server-side.
- Feed skill-wise results to the Adaptive Learning Agent and replace the next incomplete week's tasks and append an adaptation log to the linked roadmap.
- Assessment rows are read-only to authenticated clients; server routes perform writes.

## Next milestone
Build a profile editor with evidence-based profile strength, then verified local opportunity discovery and a context-aware AI mentor chat.


## Milestone 4: Opportunities and AI Mentor
- Career opportunity finder provides targeted search links for Internshala, LinkedIn Jobs, Naukri, Wellfound, Unstop, Devfolio and AICTE. These are provider search links, not a verified live vacancy feed; users must confirm listing status and eligibility on the provider site.
- AI Mentor uses Gemini with the authenticated learner profile and latest saved roadmap as context. Conversation messages are persisted in `mentor_messages`.
- Run `supabase/migrations/0004_opportunities_and_mentor.sql` after the first three migrations.
- Add `SUPABASE_SERVICE_ROLE_KEY` only if using server-only admin operations already present in the assessment flow. Keep it out of browser code and source control.
- The Mentor API requires `GEMINI_API_KEY`; opportunity search links do not require an external search API key.
