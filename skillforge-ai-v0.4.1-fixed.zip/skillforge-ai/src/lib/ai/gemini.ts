import { GoogleGenAI } from "@google/genai";

let client: GoogleGenAI | null = null;
function getGeminiClient() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) throw new Error("GEMINI_API_KEY is missing. Add it to .env.local.");
  client ??= new GoogleGenAI({ apiKey });
  return client;
}

export const GEMINI_MODEL = process.env.GEMINI_MODEL || "gemini-2.5-flash";

export async function generateJson<T>(agentName: string, instructions: string, input: unknown): Promise<T> {
  const response = await getGeminiClient().models.generateContent({
    model: GEMINI_MODEL,
    contents: [
      `You are the ${agentName} in SkillForge AI, a career-learning platform.`,
      instructions,
      "Return ONLY valid JSON. Do not wrap it in markdown fences.",
      `INPUT:\n${JSON.stringify(input)}`,
    ].join("\n\n"),
    config: { responseMimeType: "application/json", temperature: 0.25 },
  });
  const text = response.text;
  if (!text) throw new Error(`${agentName} returned an empty response.`);
  try { return JSON.parse(text) as T; }
  catch { throw new Error(`${agentName} returned invalid JSON.`); }
}
