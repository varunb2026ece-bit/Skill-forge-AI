import { generateJson } from "@/lib/ai/gemini";

export type LearnerInput = {
  targetCareer: string;
  currentSkills: string[];
  education: string;
  weeks: number;
};

type Profile = { normalizedSkills: string[]; learnerSummary: string; assumptions: string[] };
type GapAnalysis = { gaps: { skill: string; currentLevel: string; targetLevel: string; priority: "high" | "medium" | "low"; reason: string }[]; strengths: string[] };
type Plan = { profileSummary: string; roadmap: { week: number; focus: string; tasks: string[]; outcome: string }[]; resourceIdeas: { topic: string; resourceType: string; searchQuery: string }[] };
type Mentor = { mentorAdvice: string };

export async function runRoadmapAgents(input: LearnerInput) {
  // Sequential execution is intentional: each specialist consumes the prior agent's structured output.
  const profile = await generateJson<Profile>(
    "Profile Agent",
    "Normalize skill names, summarize the learner, and list assumptions. Do not invent experience. Schema: {normalizedSkills:string[], learnerSummary:string, assumptions:string[]}.",
    input
  );

  const gapAnalysis = await generateJson<GapAnalysis>(
    "Skill Gap Agent",
    `Compare the learner's normalized skills with the target career. Identify realistic missing skills. Use beginner/intermediate/advanced labels. Prioritize high/medium/low. Schema: {gaps:[{skill,currentLevel,targetLevel,priority,reason}], strengths:string[]}.`,
    { ...input, profile }
  );

  const plan = await generateJson<Plan>(
    "Roadmap Agent",
    `Create exactly ${input.weeks} weekly learning stages. Tasks must be actionable and sequenced. Suggest resource search queries, not fabricated URLs. Schema: {profileSummary:string, roadmap:[{week:number,focus:string,tasks:string[],outcome:string}], resourceIdeas:[{topic:string,resourceType:string,searchQuery:string}]}.`,
    { ...input, profile, gapAnalysis }
  );

  const mentor = await generateJson<Mentor>(
    "AI Mentor Agent",
    "Give practical, encouraging advice grounded in this learner's skills, gaps and plan. Mention one first action and how to adapt if the learner struggles. Schema: {mentorAdvice:string}.",
    { ...input, profile, gapAnalysis, plan }
  );

  return {
    profileSummary: plan.profileSummary || profile.learnerSummary,
    skillGaps: gapAnalysis.gaps ?? [],
    strengths: gapAnalysis.strengths ?? [],
    roadmap: plan.roadmap ?? [],
    resourceIdeas: plan.resourceIdeas ?? [],
    mentorAdvice: mentor.mentorAdvice,
    agentTrace: ["Profile Agent", "Skill Gap Agent", "Roadmap Agent", "AI Mentor Agent"],
  };
}
