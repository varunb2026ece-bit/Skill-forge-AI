"use client";

import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";

import { useEffect, useMemo, useState } from "react";
import {
  Activity, ArrowUpRight, BookOpen, Bot, BriefcaseBusiness, ChevronRight, ClipboardCheck,
  CircleHelp, Flame, GraduationCap, LayoutDashboard, Lightbulb, LogOut,
  MessageCircle, Plus, Search, Settings, ShieldCheck, Sparkles, Target,
  TrendingUp, UserRound, WandSparkles, Zap
} from "lucide-react";

type Assessment = {
  id: string;
  topic: string;
  feedback: {
    description: string;
    questions: { id: string; skill: string; prompt: string; options: string[] }[];
    status: "pending" | "submitted";
    correctCount?: number;
    totalQuestions?: number;
    skillStats?: { skill: string; correct: number; total: number; percentage: number }[];
    explanations?: { questionId: string; correct: boolean; correctIndex: number; explanation: string }[];
  };
};
type AssessmentResult = {
  score: number;
  correctCount: number;
  totalQuestions: number;
  skillStats: { skill: string; correct: number; total: number; percentage: number }[];
  explanations: { questionId: string; correct: boolean; correctIndex: number; explanation: string }[];
  adaptation: { summary: string; focusSkills: string[]; revisedTasks: string[]; mentorAdvice: string } | null;
};

type RoadmapResult = {
  profileSummary: string;
  skillGaps: { skill: string; currentLevel: string; targetLevel: string; priority: "high" | "medium" | "low"; reason: string }[];
  roadmap: { week: number; focus: string; tasks: string[]; outcome: string }[];
  mentorAdvice: string;
  adaptiveUpdates?: { summary: string; focusSkills: string[]; revisedTasks: string[]; mentorAdvice: string; score: number; assessedAt: string }[];
};

export default function DashboardClient({ displayName, initialGoal, initialSkills: savedSkills, initialResult }: { displayName: string; initialGoal: string; initialSkills: string[]; initialResult: RoadmapResult | null }) {
  const [goal, setGoal] = useState(initialGoal);
  const [skills, setSkills] = useState(savedSkills.join(", "));
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<RoadmapResult | null>(initialResult);
  const [error, setError] = useState("");
  const [assessment, setAssessment] = useState<Assessment | null>(null);
  const [assessmentAnswers, setAssessmentAnswers] = useState<Record<string, number>>({});
  const [assessmentBusy, setAssessmentBusy] = useState(false);
  const [assessmentResult, setAssessmentResult] = useState<AssessmentResult | null>(null);
  const [assessmentError, setAssessmentError] = useState("");
  const [active, setActive] = useState("Dashboard");
  const router = useRouter();
  const [signingOut, setSigningOut] = useState(false);
  const [opRole, setOpRole] = useState(initialGoal || "Engineering");
  const [opLocation, setOpLocation] = useState("Coimbatore, Tamil Nadu");
  const [opType, setOpType] = useState("All");
  const [opportunities, setOpportunities] = useState<{name:string;category:string;searchUrl:string;verification:string}[]>([]);
  const [opBusy, setOpBusy] = useState(false);
  const [mentorInput, setMentorInput] = useState("");
  const [mentorBusy, setMentorBusy] = useState(false);
  const [mentorMessages, setMentorMessages] = useState<{role:"user"|"assistant";content:string}[]>([]);
  const [mentorError, setMentorError] = useState("");
  const skillCount = useMemo(() => skills.split(",").map(s => s.trim()).filter(Boolean).length, [skills]);

  useEffect(() => {
    fetch("/api/mentor/history").then(r => r.ok ? r.json() : null).then(data => {
      if (data?.messages) setMentorMessages(data.messages.map((m: {role:"user"|"assistant";content:string}) => ({role:m.role,content:m.content})));
    }).catch(() => undefined);
  }, []);

  async function findOpportunities() {
    setOpBusy(true);
    try {
      const params = new URLSearchParams({ role: opRole, location: opLocation, type: opType });
      const response = await fetch(`/api/opportunities?${params}`);
      const data = await response.json();
      if (!response.ok) throw new Error(data.error ?? "Unable to load opportunity sources.");
      setOpportunities(data.results ?? []);
    } catch (e) { setMentorError(e instanceof Error ? e.message : "Opportunity search failed."); }
    finally { setOpBusy(false); }
  }

  async function sendMentorMessage() {
    const message = mentorInput.trim();
    if (!message || mentorBusy) return;
    const history = [...mentorMessages, { role: "user" as const, content: message }];
    setMentorMessages(history); setMentorInput(""); setMentorBusy(true); setMentorError("");
    try {
      const response = await fetch("/api/mentor", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ message, history: mentorMessages.slice(-8) }) });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error ?? "Mentor request failed.");
      setMentorMessages([...history, { role: "assistant", content: data.answer }]);
    } catch (e) { setMentorError(e instanceof Error ? e.message : "Mentor request failed."); }
    finally { setMentorBusy(false); }
  }

  async function signOut() {
    setSigningOut(true);
    const supabase = createClient();
    await supabase.auth.signOut();
    router.replace("/login");
    router.refresh();
  }

  async function generateRoadmap() {
    setLoading(true); setError(""); setResult(null);
    try {
      const response = await fetch("/api/agents/roadmap", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ targetCareer: goal, currentSkills: skills.split(",").map(s => s.trim()).filter(Boolean), education: "Undergraduate student", weeks: 8 }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error ?? "Unable to generate roadmap");
      setResult(data.result);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Unexpected error");
    } finally { setLoading(false); }
  }


  async function generateAssessment() {
    setAssessmentBusy(true); setAssessmentError(""); setAssessmentResult(null);
    try {
      const response = await fetch("/api/assessments", { method: "POST" });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error ?? "Unable to generate assessment.");
      setAssessment(data.assessment);
      setAssessmentAnswers({});
    } catch (e) {
      setAssessmentError(e instanceof Error ? e.message : "Assessment generation failed.");
    } finally { setAssessmentBusy(false); }
  }

  async function submitAssessment() {
    if (!assessment) return;
    setAssessmentBusy(true); setAssessmentError("");
    try {
      const answers = assessment.feedback.questions.map(q => ({
        questionId: q.id,
        selectedIndex: assessmentAnswers[q.id],
      }));
      if (answers.some(a => !Number.isInteger(a.selectedIndex))) {
        throw new Error("Answer every question before submitting.");
      }
      const response = await fetch(`/api/assessments/${assessment.id}/submit`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ answers }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error ?? "Unable to submit assessment.");
      setAssessmentResult(data);
      setAssessment({ ...assessment, feedback: { ...assessment.feedback, status: "submitted" } });
      router.refresh();
    } catch (e) {
      setAssessmentError(e instanceof Error ? e.message : "Assessment submission failed.");
    } finally { setAssessmentBusy(false); }
  }

  const nav = [
    { label: "Dashboard", icon: LayoutDashboard },
    { label: "My Roadmap", icon: Target },
    { label: "Local Opportunities", icon: BriefcaseBusiness },
    { label: "Mentorship", icon: Bot },
    { label: "Settings", icon: Settings },
  ];

  return (
    <main className="app-shell">
      <aside className="sidebar">
        <div className="brand"><span className="brand-mark"><Sparkles size={19}/></span><span>SkillForge <b>AI</b></span></div>
        <div className="nav-caption">MAIN NAVIGATION</div>
        <nav>{nav.map(item => <button key={item.label} onClick={() => setActive(item.label)} className={`nav-item ${active === item.label ? "selected" : ""}`}><item.icon size={17}/>{item.label}</button>)}</nav>
        <div className="sidebar-bottom"><div className="user-mini"><div className="avatar">{displayName.slice(0, 2).toUpperCase()}</div><div><strong>{displayName}</strong><small>Personal workspace</small></div></div><button className="nav-item" onClick={signOut} disabled={signingOut}><LogOut size={17}/>{signingOut ? "Signing out..." : "Sign Out"}</button></div>
      </aside>

      <section className="main-panel">
        <header className="topbar">
          <div><div className="eyebrow">CAREER INTELLIGENCE WORKSPACE</div><h1>Welcome back, {displayName || "Learner"} <span>✦</span></h1><p>Turn your current skills into your next opportunity.</p></div>
          <button className="icon-button" aria-label="Help"><CircleHelp size={19}/></button>
        </header>

        <section className="metric-grid">
          <Metric icon={<Activity/>} label="Skill Score" value="78/100" note="+12% from last month" color="mint"/>
          <Metric icon={<Flame/>} label="Learning Streak" value="14 Days" note="Keep the momentum" color="orange"/>
          <Metric icon={<BriefcaseBusiness/>} label="Career Matches" value="12 Matched" note="Based on your profile" color="violet"/>
          <Metric icon={<ShieldCheck/>} label="Profile Strength" value="High" note="Add a project to improve" color="blue"/>
        </section>

        <section className="content-grid">
          <div className="panel growth-panel">
            <div className="panel-heading"><div><h2>Skill Growth Forecast</h2><p>Your learning momentum over the next 5 weeks</p></div><span className="pill"><TrendingUp size={13}/> Forecast</span></div>
            <div className="chart-wrap">
              <svg viewBox="0 0 720 270" role="img" aria-label="Illustrative skill growth chart" className="growth-chart">
                <defs><linearGradient id="area" x1="0" x2="0" y1="0" y2="1"><stop offset="0%" stopColor="#20c997" stopOpacity=".28"/><stop offset="100%" stopColor="#20c997" stopOpacity="0"/></linearGradient></defs>
                {[35,85,135,185,235].map(y=><line key={y} x1="55" x2="690" y1={y} y2={y} className="grid-line"/>)}
                <path d="M55 205 C145 180 190 160 270 143 S420 112 485 82 S615 42 690 22 L690 235 L55 235 Z" fill="url(#area)"/>
                <path d="M55 205 C145 180 190 160 270 143 S420 112 485 82 S615 42 690 22" className="chart-line"/>
                {[["Week 1",55,205],["Week 2",205,164],["Week 3",350,125],["Week 4",500,76],["Week 5",690,22]].map(([label,x,y])=><g key={String(label)}><circle cx={Number(x)} cy={Number(y)} r="4" className="chart-dot"/><text x={Number(x)} y="258" textAnchor="middle" className="axis-label">{String(label)}</text></g>)}
                <text x="12" y="38" className="axis-label">100</text><text x="20" y="138" className="axis-label">50</text><text x="27" y="238" className="axis-label">0</text>
              </svg>
              <div className="chart-footnote"><span><i className="legend-dot"/>Projected skill growth</span><small>Illustrative demo forecast, not measured data</small></div>
            </div>
          </div>

          <div className="panel focus-panel">
            <div className="panel-heading"><div><h2>Learning Focus</h2><p>Recommended time allocation</p></div></div>
            <div className="donut-area"><div className="donut"><div><strong>100%</strong><small>Focus plan</small></div></div></div>
            <div className="legend-list"><Legend color="mint" label="Technical skills" value="50%"/><Legend color="blue" label="Core concepts" value="30%"/><Legend color="orange" label="Projects" value="20%"/></div>
          </div>
        </section>

        <section className="bottom-grid">
          <div className="panel goal-panel">
            <div className="panel-heading"><div><h2>Build your career roadmap</h2><p>Run the specialist AI agents on your profile.</p></div><span className="ai-tag"><WandSparkles size={13}/> MULTI-AGENT AI</span></div>
            <label>Target career role</label>
            <div className="input-wrap"><Target size={17}/><input value={goal} onChange={e => setGoal(e.target.value)} placeholder="e.g. Embedded Systems Engineer"/></div>
            <label>Current skills <small>Separate skills with commas</small></label>
            <textarea value={skills} onChange={e => setSkills(e.target.value)} rows={3} placeholder="Python, C, SQL, HTML"/>
            <div className="form-footer"><span>{skillCount} skills detected</span><button className="primary-button" onClick={generateRoadmap} disabled={loading || !goal.trim() || skillCount === 0}>{loading ? <><span className="spinner"/> Agents working...</> : <><Sparkles size={16}/> Generate roadmap <ArrowUpRight size={15}/></>}</button></div>
            {error && <p className="error-text">{error}</p>}
          </div>
          <div className="panel mentor-card">
            <div className="mentor-icon"><Bot size={23}/></div><span className="eyebrow">YOUR AI MENTOR</span><h2>Make your next move count.</h2><p>Get a clear path from where you are to where you want to be, with guidance that adapts as you learn.</p><div className="mentor-bottom"><span><Zap size={14}/> Context-aware guidance</span><span><MessageCircle size={14}/> Ask anytime</span></div>
          </div>
        </section>

        <section className="panel assessment-panel">
          <div className="panel-heading">
            <div><h2><ClipboardCheck size={16} style={{display:"inline",verticalAlign:"-3px",marginRight:7}}/> AI Skill Assessment</h2><p>Test your current understanding and let the Adaptive Learning Agent refine your roadmap.</p></div>
            <span className="ai-tag">ASSESSMENT AGENT</span>
          </div>
          {!assessment && <div className="assessment-start">
            <div><strong>5-question career readiness check</strong><small>Questions are generated from your saved career goal and latest roadmap.</small></div>
            <button className="primary-button" onClick={generateAssessment} disabled={assessmentBusy}>{assessmentBusy ? "Generating quiz..." : <><ClipboardCheck size={15}/> Generate assessment</>}</button>
          </div>}
          {assessment && <div className="assessment-body">
            <h3>{assessment.topic}</h3><p className="assessment-description">{assessment.feedback.description}</p>
            {assessment.feedback.questions.map((q,index) => <div className="question-card" key={q.id}>
              <div className="question-meta"><span>QUESTION {index+1} / {assessment.feedback.questions.length}</span><span>{q.skill}</span></div>
              <strong>{q.prompt}</strong>
              <div className="option-list">{q.options.map((option,optionIndex) => <label key={optionIndex} className={`quiz-option ${assessmentAnswers[q.id]===optionIndex?"chosen":""}`}>
                <input type="radio" name={q.id} checked={assessmentAnswers[q.id]===optionIndex} disabled={assessment.feedback.status==="submitted"} onChange={()=>setAssessmentAnswers(prev=>({...prev,[q.id]:optionIndex}))}/>
                <span>{option}</span>
              </label>)}</div>
            </div>)}
            {assessment.feedback.status==="pending" && <div className="assessment-actions"><span>{Object.keys(assessmentAnswers).length} of {assessment.feedback.questions.length} answered</span><button className="primary-button" onClick={submitAssessment} disabled={assessmentBusy}>{assessmentBusy?"Evaluating...":"Submit answers"}</button></div>}
            {assessmentError && <p className="error-text" role="alert">{assessmentError}</p>}
          </div>}
          {assessmentResult && <div className="assessment-results">
            <div className="score-display"><strong>{assessmentResult.score}%</strong><span>{assessmentResult.correctCount} of {assessmentResult.totalQuestions} correct</span></div>
            <h3>Skill-wise performance</h3>
            <div className="skill-results">{assessmentResult.skillStats.map(item=><div key={item.skill}><span>{item.skill}</span><strong>{item.percentage}%</strong><div className="score-track"><i style={{width:`${item.percentage}%`}}/></div></div>)}</div>
            <h3>Answer explanations</h3>
            {assessmentResult.explanations.map((item,index)=><p className="explanation-row" key={item.questionId}><strong>{index+1}. {item.correct?"Correct":"Review this concept"}</strong> — {item.explanation}</p>)}
            {assessmentResult.adaptation && <div className="mentor-advice"><Lightbulb size={18}/><p><strong>Adaptive roadmap updated</strong><br/>{assessmentResult.adaptation.summary}<br/><br/><strong>Focus next:</strong> {assessmentResult.adaptation.focusSkills.join(", ")}<br/><strong>Mentor:</strong> {assessmentResult.adaptation.mentorAdvice}</p></div>}
            <button className="secondary-button" onClick={()=>{setAssessment(null);setAssessmentResult(null);setAssessmentAnswers({});}}>Generate another assessment</button>
          </div>}
        </section>

        {result && <section className="panel result-panel">
          <div className="panel-heading"><div><span className="ai-tag"><Sparkles size={13}/> AGENT OUTPUT</span><h2>Your personalized roadmap</h2><p>{result.profileSummary}</p></div></div>
          <h3>Priority skill gaps</h3>
          <div className="gap-list">{result.skillGaps?.map(g => <div className="gap-row" key={g.skill}><div><strong>{g.skill}</strong><small>{g.currentLevel} → {g.targetLevel}</small></div><span className={`priority ${g.priority}`}>{g.priority}</span><p>{g.reason}</p></div>)}</div>
          <h3>Learning plan</h3>
          <div className="roadmap-list">{result.roadmap?.map(w => <div className="week-row" key={w.week}><div className="week-number">W{w.week}</div><div><strong>{w.focus}</strong><ul>{w.tasks?.map(t => <li key={t}>{t}</li>)}</ul><small>Outcome: {w.outcome}</small></div></div>)}</div>
          <div className="mentor-advice"><Lightbulb size={18}/><p><strong>AI Mentor advice</strong><br/>{result.mentorAdvice}</p></div>
          {result.adaptiveUpdates?.length ? <div className="adaptive-saved">
            <strong><Activity size={14}/> Latest adaptive update · {result.adaptiveUpdates[result.adaptiveUpdates.length-1].score}% assessment</strong>
            <p>{result.adaptiveUpdates[result.adaptiveUpdates.length-1].summary}</p>
            <small>Next focus: {result.adaptiveUpdates[result.adaptiveUpdates.length-1].focusSkills.join(", ")}</small>
          </div> : null}
        </section>}

        <section className="panel opportunity-panel">
          <div className="panel-heading"><div><h2><BriefcaseBusiness size={16} style={{display:"inline",verticalAlign:"-3px",marginRight:7}}/> Career Opportunities</h2><p>Find external job, internship and hackathon search portals matched to your target.</p></div><span className="ai-tag">OPPORTUNITY FINDER</span></div>
          <div className="opportunity-filters">
            <label>Role / keyword<input value={opRole} onChange={e=>setOpRole(e.target.value)} placeholder="Embedded systems, Python, AI..."/></label>
            <label>Location<input value={opLocation} onChange={e=>setOpLocation(e.target.value)} placeholder="City, state or remote"/></label>
            <label>Type<select value={opType} onChange={e=>setOpType(e.target.value)}><option>All</option><option>Internships</option><option>Jobs</option><option>Hackathons</option></select></label>
            <button className="primary-button" onClick={findOpportunities} disabled={opBusy}>{opBusy?"Loading...":"Find opportunities"}<Search size={14}/></button>
          </div>
          {opportunities.length>0 && <div className="opportunity-list">{opportunities.map(item=><article className="opportunity-item" key={item.name}><div><strong>{item.name}</strong><small>{item.category}</small><p>{item.verification}</p></div><a href={item.searchUrl} target="_blank" rel="noreferrer">Open search <ArrowUpRight size={13}/></a></article>)}</div>}
          <p className="source-disclaimer">These are provider search destinations, not verified live vacancies. Confirm listing status, eligibility, location and deadlines on each provider's website.</p>
        </section>

        <section className="panel mentor-chat-panel">
          <div className="panel-heading"><div><h2><Bot size={16} style={{display:"inline",verticalAlign:"-3px",marginRight:7}}/> AI Career Mentor</h2><p>Context-aware guidance using your saved profile and latest roadmap.</p></div><span className="ai-tag">GEMINI MENTOR</span></div>
          <div className="mentor-thread" aria-live="polite">{mentorMessages.length===0 && <p className="mentor-empty">Ask about career choices, skill gaps, projects, interview preparation or your next learning step.</p>}{mentorMessages.map((m,i)=><div className={`mentor-message ${m.role}`} key={i}><b>{m.role==="user"?"You":"SkillForge Mentor"}</b><p>{m.content}</p></div>)}</div>
          <form className="mentor-compose" onSubmit={e=>{e.preventDefault();void sendMentorMessage();}}><input value={mentorInput} onChange={e=>setMentorInput(e.target.value)} placeholder="Ask your career mentor..." maxLength={2000}/><button className="primary-button" disabled={mentorBusy||!mentorInput.trim()}>{mentorBusy?"Thinking...":"Send"}<ArrowUpRight size={14}/></button></form>
          {mentorError && <p className="error-text" role="alert">{mentorError}</p>}
        </section>

        <footer className="footer-note"><span>SkillForge AI · Prototype workspace</span><span><span className="status-dot"/> Systems operational</span></footer>
      </section>
      <button className="chat-fab" aria-label="Open AI mentor" onClick={() => setActive("Mentorship")}><MessageCircle size={21}/></button>
    </main>
  );
}

function Metric({ icon, label, value, note, color }: { icon: React.ReactNode; label: string; value: string; note: string; color: string }) {
  return <div className="metric-card"><div className="metric-top"><span>{label}</span><span className={`metric-icon ${color}`}>{icon}</span></div><strong>{value}</strong><small>{note}</small></div>;
}
function Legend({ color, label, value }: { color: string; label: string; value: string }) {
  return <div className="legend-row"><span><i className={`legend-dot ${color}`}/>{label}</span><strong>{value}</strong></div>;
}
