import { redirect } from "next/navigation";
import DashboardClient from "./dashboard-client";
import { createClient } from "@/lib/supabase/server";

type SavedRoadmap = { profileSummary: string; skillGaps: { skill: string; currentLevel: string; targetLevel: string; priority: "high" | "medium" | "low"; reason: string }[]; roadmap: { week: number; focus: string; tasks: string[]; outcome: string }[]; mentorAdvice: string; adaptiveUpdates?: { summary: string; focusSkills: string[]; revisedTasks: string[]; mentorAdvice: string; score: number; assessedAt: string }[] };

export default async function DashboardPage() {
  const supabase = await createClient();
  const { data: { user }, error } = await supabase.auth.getUser();
  if (error || !user) redirect("/login");

  const [{ data: profile }, { data: latestRoadmap }] = await Promise.all([
    supabase.from("learner_profiles").select("display_name, target_career, skills").eq("id", user.id).maybeSingle(),
    supabase.from("roadmaps").select("agent_result, target_career").eq("user_id", user.id).order("created_at", { ascending: false }).limit(1).maybeSingle(),
  ]);

  const savedSkills = Array.isArray(profile?.skills) ? profile.skills.filter((s): s is string => typeof s === "string") : [];
  const savedResult = latestRoadmap?.agent_result as SavedRoadmap | null;
  return <DashboardClient
    displayName={profile?.display_name || user.user_metadata?.display_name || user.email?.split("@")[0] || "Learner"}
    initialGoal={profile?.target_career || latestRoadmap?.target_career || "AI Engineer"}
    initialSkills={savedSkills.length ? savedSkills : ["Python", "C programming", "SQL", "HTML"]}
    initialResult={savedResult}
  />;
}
