"use client";

import { FormEvent, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";

export default function LoginPage() {
  const router = useRouter();
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setBusy(true); setError(""); setMessage("");
    const supabase = createClient();
    try {
      if (mode === "signup") {
        const { data, error: authError } = await supabase.auth.signUp({
          email, password, options: { data: { display_name: displayName.trim() }, emailRedirectTo: `${window.location.origin}/auth/callback` },
        });
        if (authError) throw authError;
        if (!data.session) {
          setMessage("Account created. Check your email to confirm your address, then sign in.");
        } else {
          router.replace("/dashboard"); router.refresh();
        }
      } else {
        const { error: authError } = await supabase.auth.signInWithPassword({ email, password });
        if (authError) throw authError;
        router.replace("/dashboard"); router.refresh();
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : "Authentication failed.");
    } finally { setBusy(false); }
  }

  return <main className="auth-shell"><section className="auth-card">
    <div className="brand auth-brand"><span className="brand-mark">✦</span><span>SkillForge <b>AI</b></span></div>
    <div className="eyebrow">CAREER INTELLIGENCE WORKSPACE</div>
    <h1>{mode === "signin" ? "Welcome back" : "Create your learner account"}</h1>
    <p className="auth-subtitle">{mode === "signin" ? "Sign in to continue your personalized learning journey." : "Build a profile, discover your skill gaps, and plan your next move."}</p>
    <form onSubmit={submit} className="auth-form">
      {mode === "signup" && <label>Display name<input required maxLength={80} value={displayName} onChange={e=>setDisplayName(e.target.value)} placeholder="Your name" /></label>}
      <label>Email address<input type="email" required autoComplete="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@example.com" /></label>
      <label>Password<input type="password" required minLength={8} autoComplete={mode === "signin" ? "current-password" : "new-password"} value={password} onChange={e=>setPassword(e.target.value)} placeholder="At least 8 characters" /></label>
      {error && <p className="auth-error" role="alert">{error}</p>}
      {message && <p className="auth-success" role="status">{message}</p>}
      <button className="primary-button auth-submit" disabled={busy}>{busy ? "Please wait..." : mode === "signin" ? "Sign in" : "Create account"}</button>
    </form>
    <p className="auth-switch">{mode === "signin" ? "New to SkillForge AI?" : "Already have an account?"} <button onClick={()=>{setMode(mode === "signin" ? "signup" : "signin");setError("");setMessage("")}}>{mode === "signin" ? "Create account" : "Sign in"}</button></p>
    <Link className="back-link" href="/">Back to home</Link>
  </section></main>;
}
