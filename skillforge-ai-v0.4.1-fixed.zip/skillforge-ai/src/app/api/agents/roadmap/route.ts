import { NextResponse } from "next/server";
import { runRoadmapAgents } from "@/lib/agents/orchestrator";
import { createClient } from "@/lib/supabase/server";

export const runtime = "nodejs";
export const maxDuration = 60;
type Payload = { targetCareer?: string; currentSkills?: string[]; education?: string; weeks?: number };

export async function POST(request: Request) {
  try {
    const supabase = await createClient();
    const { data: { user }, error: authError } = await supabase.auth.getUser();
    if (authError || !user) return NextResponse.json({ error: "Authentication required." }, { status: 401 });

    const body = (await request.json()) as Payload;
    const targetCareer = body.targetCareer?.trim();
    const currentSkills = body.currentSkills;
    if (!targetCareer || targetCareer.length > 120) return NextResponse.json({ error: "Provide a valid target career (max 120 characters)." }, { status: 400 });
    if (!Array.isArray(currentSkills) || currentSkills.length < 1 || currentSkills.length > 40 ||
      !currentSkills.every(s => typeof s === "string" && s.trim().length > 0 && s.length <= 80)) {
      return NextResponse.json({ error: "Provide between 1 and 40 valid current skills." }, { status: 400 });
    }

    const education = (body.education ?? "Not specified").slice(0, 160);
    const weeks = Math.min(16, Math.max(4, Number.isFinite(Number(body.weeks)) ? Number(body.weeks) : 8));
    const normalizedSkills = currentSkills.map(s => s.trim());
    const result = await runRoadmapAgents({ targetCareer, currentSkills: normalizedSkills, education, weeks });

    const { error: profileError } = await supabase.from("learner_profiles").upsert({
      id: user.id,
      display_name: user.user_metadata?.display_name ?? user.email?.split("@")[0] ?? "Learner",
      education,
      target_career: targetCareer,
      skills: normalizedSkills,
      updated_at: new Date().toISOString(),
    }, { onConflict: "id" });
    if (profileError) throw new Error(`Profile save failed: ${profileError.message}`);

    const { data: savedRoadmap, error: roadmapError } = await supabase.from("roadmaps").insert({
      user_id: user.id,
      target_career: targetCareer,
      input_snapshot: { currentSkills: normalizedSkills, education, weeks },
      agent_result: result,
      status: "active",
    }).select("id, created_at").single();
    if (roadmapError) throw new Error(`Roadmap save failed: ${roadmapError.message}`);

    return NextResponse.json({ result, roadmap: savedRoadmap });
  } catch (error) {
    console.error("roadmap agent error", error);
    return NextResponse.json({ error: error instanceof Error ? error.message : "Agent workflow failed." }, { status: 500 });
  }
}
