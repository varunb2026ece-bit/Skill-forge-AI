import { NextResponse } from "next/server";
import { generateJson } from "@/lib/ai/gemini";
import { createClient } from "@/lib/supabase/server";

export const runtime = "nodejs";

type Message = { role: "user" | "assistant"; content: string };
export async function POST(request: Request) {
  try {
    const supabase = await createClient();
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return NextResponse.json({ error: "Authentication required." }, { status: 401 });
    const body = await request.json() as { message?: string; history?: Message[] };
    const message = body.message?.trim();
    if (!message || message.length > 2000) return NextResponse.json({ error: "Message must contain 1–2000 characters." }, { status: 400 });
    const history = Array.isArray(body.history) ? body.history.slice(-8).filter(m => (m.role === "user" || m.role === "assistant") && typeof m.content === "string").map(m => ({ role: m.role, content: m.content.slice(0, 2000) })) : [];
    const [{ data: profile }, { data: roadmap }] = await Promise.all([
      supabase.from("learner_profiles").select("target_career, skills, education").eq("id", user.id).maybeSingle(),
      supabase.from("roadmaps").select("agent_result").eq("user_id", user.id).order("created_at", { ascending: false }).limit(1).maybeSingle(),
    ]);
    const answer = await generateJson<{ answer: string; suggestedActions: string[] }>(
      "SkillForge AI Career Mentor",
      "Act as a practical, supportive career and learning mentor. Use learner context when relevant, avoid guaranteeing jobs or outcomes, distinguish estimates from facts, and give concise actionable advice. Return JSON {answer:string,suggestedActions:string[]}. Do not invent internships, deadlines, salaries, or credentials.",
      { profile, roadmap: roadmap?.agent_result ?? null, recentConversation: history, question: message }
    );
    const assistantText = answer.answer?.trim();
    if (!assistantText) throw new Error("Mentor returned an empty answer.");
    const { error } = await supabase.from("mentor_messages").insert([
      { user_id: user.id, role: "user", content: message },
      { user_id: user.id, role: "assistant", content: assistantText, metadata: { suggestedActions: answer.suggestedActions ?? [] } },
    ]);
    if (error) throw new Error(`Unable to save mentor conversation: ${error.message}`);
    return NextResponse.json({ answer: assistantText, suggestedActions: answer.suggestedActions ?? [] });
  } catch (error) {
    console.error("mentor route error", error);
    return NextResponse.json({ error: error instanceof Error ? error.message : "Mentor request failed." }, { status: 500 });
  }
}
