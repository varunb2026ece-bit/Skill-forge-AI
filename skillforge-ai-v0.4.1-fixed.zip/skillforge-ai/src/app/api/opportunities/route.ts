import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

const providers = [
  { name: "Internshala", category: "Internships", url: "https://internshala.com/internships/" },
  { name: "LinkedIn Jobs", category: "Jobs", url: "https://www.linkedin.com/jobs/" },
  { name: "Naukri", category: "Jobs", url: "https://www.naukri.com/" },
  { name: "Wellfound", category: "Startup jobs", url: "https://wellfound.com/jobs" },
  { name: "Unstop", category: "Hackathons & competitions", url: "https://unstop.com/hackathons" },
  { name: "Devfolio", category: "Hackathons", url: "https://devfolio.co/hackathons" },
  { name: "AICTE Internship Portal", category: "Internships", url: "https://internship.aicte-india.org/" },
];

export async function GET(request: Request) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Authentication required." }, { status: 401 });
  const params = new URL(request.url).searchParams;
  const role = (params.get("role") ?? "software engineering").slice(0, 100);
  const location = (params.get("location") ?? "India").slice(0, 100);
  const type = params.get("type") ?? "All";
  const q = encodeURIComponent(`${role} ${location}`);
  const results = providers.filter(p => type === "All" || p.category.toLowerCase().includes(type.toLowerCase()) || (type === "Hackathons" && p.category.toLowerCase().includes("hackathon"))).map(p => ({
    ...p,
    searchUrl: p.name === "Internshala" ? `https://internshala.com/internships/${encodeURIComponent(role.toLowerCase().replaceAll(" ", "-"))}-internship/` : p.name === "LinkedIn Jobs" ? `https://www.linkedin.com/jobs/search/?keywords=${q}&location=${encodeURIComponent(location)}` : p.name === "Naukri" ? `https://www.naukri.com/${role.toLowerCase().replaceAll(" ", "-")}-jobs-in-${location.toLowerCase().replaceAll(" ", "-")}` : p.name === "Unstop" ? "https://unstop.com/hackathons" : p.name === "Devfolio" ? "https://devfolio.co/hackathons" : p.name === "AICTE Internship Portal" ? p.url : `https://wellfound.com/jobs`,
    verification: "External search link — listings, eligibility and deadlines must be checked on the provider site.",
  }));
  return NextResponse.json({ results, query: { role, location, type } });
}
