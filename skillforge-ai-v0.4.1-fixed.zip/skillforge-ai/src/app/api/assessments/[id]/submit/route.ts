import { NextResponse } from "next/server";
import { generateJson } from "@/lib/ai/gemini";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";

export const runtime = "nodejs";
export const maxDuration = 45;

type AnswerKeyItem = { id: string; skill: string; correctIndex: number; explanation: string };
type SubmittedAnswer = { questionId: string; selectedIndex: number };

export async function POST(request: Request, context: { params: Promise<{ id: string }> }) {
  try {
    const supabase = await createClient();
    const { data: { user }, error: authError } = await supabase.auth.getUser();
    if (authError || !user) return NextResponse.json({ error: "Authentication required." }, { status: 401 });

    const { id } = await context.params;
    const body = await request.json() as { answers?: SubmittedAnswer[] };
    if (!Array.isArray(body.answers) || body.answers.length !== 5 ||
      !body.answers.every((a) => typeof a.questionId === "string" && Number.isInteger(a.selectedIndex) && a.selectedIndex >= 0 && a.selectedIndex <= 3)) {
      return NextResponse.json({ error: "Submit one valid answer for each of the five questions." }, { status: 400 });
    }

    const { data: assessment, error: assessmentError } = await supabase
      .from("assessments").select("id, user_id, roadmap_id, topic, feedback, score")
      .eq("id", id).eq("user_id", user.id).single();
    if (assessmentError || !assessment) return NextResponse.json({ error: "Assessment not found." }, { status: 404 });
    if (assessment.score !== null) return NextResponse.json({ error: "This assessment has already been submitted." }, { status: 409 });

    const admin = createAdminClient();
    const { data: keyRecord, error: keyError } = await admin.from("assessment_answer_keys")
      .select("answer_key").eq("assessment_id", id).eq("user_id", user.id).single();
    if (keyError || !keyRecord) throw new Error("Private answer key unavailable.");

    const key = keyRecord.answer_key as AnswerKeyItem[];
    const questionIds = new Set(key.map((item) => item.id));
    if (body.answers.some((answer) => !questionIds.has(answer.questionId)) || new Set(body.answers.map(a => a.questionId)).size !== 5) {
      return NextResponse.json({ error: "Answers do not match this assessment." }, { status: 400 });
    }

    const answerMap = new Map(body.answers.map(a => [a.questionId, a.selectedIndex]));
    const detailed = key.map(item => ({
      questionId: item.id,
      skill: item.skill,
      selectedIndex: answerMap.get(item.id)!,
      correct: answerMap.get(item.id) === item.correctIndex,
      correctIndex: item.correctIndex,
      explanation: item.explanation,
    }));
    const correctCount = detailed.filter(a => a.correct).length;
    const score = Math.round((correctCount / key.length) * 100);
    const skillStats = Object.values(detailed.reduce<Record<string, { skill: string; correct: number; total: number }>>((acc, answer) => {
      acc[answer.skill] ??= { skill: answer.skill, correct: 0, total: 0 };
      acc[answer.skill].total += 1;
      if (answer.correct) acc[answer.skill].correct += 1;
      return acc;
    }, {})).map(item => ({ ...item, percentage: Math.round(item.correct / item.total * 100) }));

    const publicFeedback = {
      ...(assessment.feedback as Record<string, unknown>),
      status: "submitted",
      correctCount,
      totalQuestions: key.length,
      skillStats,
      explanations: detailed.map(({ questionId, correct, correctIndex, explanation }) => ({ questionId, correct, correctIndex, explanation })),
    };

    const { data: updatedAssessment, error: updateError } = await admin.from("assessments").update({
      score, answers: body.answers, feedback: publicFeedback,
    }).eq("id", id).eq("user_id", user.id).is("score", null).select("id").maybeSingle();
    if (updateError) throw new Error(`Could not save assessment result: ${updateError.message}`);
    if (!updatedAssessment) return NextResponse.json({ error: "This assessment has already been submitted." }, { status: 409 });

    await admin.from("assessment_answer_keys").delete().eq("assessment_id", id);

    let adaptation: { summary: string; focusSkills: string[]; revisedTasks: string[]; mentorAdvice: string } | null = null;
    if (assessment.roadmap_id) {
      const { data: roadmap } = await supabase.from("roadmaps").select("agent_result, target_career")
        .eq("id", assessment.roadmap_id).eq("user_id", user.id).single();
      if (roadmap) {
        try {
          adaptation = await generateJson(
            "Adaptive Learning Agent",
            "Adapt the learner's existing roadmap using the assessment evidence. Prioritize skills scoring below 70%. Return 3 to 5 concrete revisedTasks for the next incomplete week only; the server will replace that week's tasks and preserve all other weeks. Keep completed learning stages intact. Be specific and realistic. Return JSON: {summary:string,focusSkills:string[],revisedTasks:string[],mentorAdvice:string}. Do not claim the learner has mastered skills based on one short quiz.",
            { targetCareer: roadmap.target_career, previousRoadmap: roadmap.agent_result, score, skillStats }
          );
          const previous = roadmap.agent_result as Record<string, unknown>;
          const existingWeeks = Array.isArray(previous.roadmap)
            ? previous.roadmap as { week: number; tasks: string[]; [key: string]: unknown }[]
            : [];
          const { data: completedRows } = await supabase.from("learning_progress")
            .select("week_number").eq("roadmap_id", assessment.roadmap_id)
            .eq("user_id", user.id).eq("completed", true);
          const completedWeeks = new Set((completedRows ?? []).map((row: { week_number: number }) => row.week_number));
          const nextWeek = existingWeeks.find(week => !completedWeeks.has(week.week));
          const adaptationResult = adaptation;
          const revisedTasks = adaptationResult?.revisedTasks ?? [];
          const revisedRoadmap = nextWeek && revisedTasks.length > 0
            ? existingWeeks.map(week => week.week === nextWeek.week
                ? { ...week, tasks: revisedTasks }
                : week)
            : existingWeeks;
          const { error: roadmapUpdateError } = await supabase.from("roadmaps").update({
            agent_result: {
              ...previous,
              roadmap: revisedRoadmap,
              adaptiveUpdates: [...(Array.isArray(previous.adaptiveUpdates) ? previous.adaptiveUpdates : []), {
                assessedAt: new Date().toISOString(), score,
                updatedWeek: nextWeek?.week ?? null,
                ...(adaptationResult ?? {}),
              }],
            },
          }).eq("id", assessment.roadmap_id).eq("user_id", user.id);
          if (roadmapUpdateError) {
            console.error("adaptive roadmap update failed", roadmapUpdateError.message);
            adaptation = null;
          }
        } catch (adaptiveError) {
          // The assessment is already scored and persisted. Do not report the submission as failed
          // merely because the optional roadmap adaptation step is temporarily unavailable.
          console.error("adaptive learning agent failed", adaptiveError);
          adaptation = null;
        }
      }
    }

    return NextResponse.json({ score, correctCount, totalQuestions: key.length, skillStats, explanations: publicFeedback.explanations, adaptation });
  } catch (error) {
    console.error("assessment submission error", error);
    return NextResponse.json({ error: error instanceof Error ? error.message : "Assessment submission failed." }, { status: 500 });
  }
}
