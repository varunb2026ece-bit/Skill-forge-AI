import { NextResponse } from "next/server";
import { generateJson } from "@/lib/ai/gemini";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";

export const runtime = "nodejs";
export const maxDuration = 45;

type GeneratedQuiz = {
  title: string;
  description: string;
  questions: {
    id: string;
    skill: string;
    prompt: string;
    options: string[];
    correctIndex: number;
    explanation: string;
  }[];
};

function validQuiz(value: GeneratedQuiz): boolean {
  return typeof value?.title === "string" &&
    typeof value?.description === "string" &&
    Array.isArray(value.questions) && value.questions.length === 5 &&
    new Set(value.questions.map((q) => q.id)).size === value.questions.length &&
    value.questions.every((q) =>
      typeof q.id === "string" && q.id.length > 0 && typeof q.skill === "string" && q.skill.length > 0 &&
      typeof q.prompt === "string" && Array.isArray(q.options) &&
      q.options.length === 4 && q.options.every((o) => typeof o === "string") &&
      Number.isInteger(q.correctIndex) && q.correctIndex >= 0 && q.correctIndex < 4 &&
      typeof q.explanation === "string"
    );
}

export async function POST() {
  try {
    const supabase = await createClient();
    const { data: { user }, error: authError } = await supabase.auth.getUser();
    if (authError || !user) return NextResponse.json({ error: "Authentication required." }, { status: 401 });

    const [{ data: profile }, { data: roadmap }] = await Promise.all([
      supabase.from("learner_profiles").select("target_career, skills, education").eq("id", user.id).maybeSingle(),
      supabase.from("roadmaps").select("id, target_career, agent_result").eq("user_id", user.id).eq("status", "active").order("created_at", { ascending: false }).limit(1).maybeSingle(),
    ]);

    if (!profile?.target_career || !roadmap) {
      return NextResponse.json({ error: "Generate a career roadmap before starting an assessment." }, { status: 409 });
    }

    const result = await generateJson<GeneratedQuiz>(
      "Assessment Agent",
      "Create exactly 5 fair multiple-choice questions to assess the learner's readiness for the target career. Cover different skills from the provided skill gaps and roadmap. Avoid ambiguous questions. Each question must have exactly 4 options and one correct answer. Include a concise explanation. Return schema: {title:string,description:string,questions:[{id:string,skill:string,prompt:string,options:string[4],correctIndex:number,explanation:string}]}. Do not reveal answers outside correctIndex.",
      { targetCareer: profile.target_career, currentSkills: profile.skills, education: profile.education, roadmap: roadmap.agent_result }
    );

    if (!validQuiz(result)) throw new Error("Assessment Agent returned an invalid quiz structure.");

    const publicQuestions = result.questions.map(({ correctIndex: _answer, explanation: _explanation, ...question }) => question);
    const admin = createAdminClient();
    const { data: assessment, error: insertError } = await admin.from("assessments").insert({
      user_id: user.id,
      roadmap_id: roadmap.id,
      topic: result.title,
      score: null,
      max_score: 100,
      answers: [],
      feedback: { description: result.description, questions: publicQuestions, status: "pending" },
    }).select("id, topic, feedback, created_at").single();
    if (insertError) throw new Error(`Could not save assessment: ${insertError.message}`);

    const { error: keyError } = await admin.from("assessment_answer_keys").insert({
      assessment_id: assessment.id,
      user_id: user.id,
      answer_key: result.questions.map(({ id, skill, correctIndex, explanation }) => ({ id, skill, correctIndex, explanation })),
    });
    if (keyError) {
      await admin.from("assessments").delete().eq("id", assessment.id).eq("user_id", user.id);
      throw new Error(`Could not securely store assessment answer key: ${keyError.message}`);
    }

    return NextResponse.json({ assessment });
  } catch (error) {
    console.error("assessment generation error", error);
    return NextResponse.json({ error: error instanceof Error ? error.message : "Assessment generation failed." }, { status: 500 });
  }
}
